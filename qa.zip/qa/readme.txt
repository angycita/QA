========================================================================
PRUEBA TECNICA - AUTOMATIZACION E2E Y PRUEBAS DE APIS
Opcion elegida E2E : Opcion 2 - SauceDemo (flujo de compra)
Opcion elegida APIS: Opcion 2 - PetStore (gestion de mascotas)
Herramienta         : Cypress 16 (un solo framework para UI y REST)
========================================================================

1. REQUISITOS PREVIOS
------------------------------------------------------------------------
- Node.js 18 o superior (probado con Node 22.22.2)
- npm 9 o superior (probado con npm 11.15.0)
- Conexion a internet (ambos ejercicios corren contra sitios publicos)
- Sistema operativo Windows
- Navegador adicional:Edge.
 
2. INSTALACION
------------------------------------------------------------------------
Desde la carpeta raíz del repositorio ejecutar:

    npm install

Ese comando instala Cypress y las utilidades de reporte declaradas en
package.json (mochawesome, mochawesome-merge y mochawesome-report-generator).

Verificación opcional del binario de Cypress:

    npx cypress verify

3. EJECUCION PASO A PASO
------------------------------------------------------------------------
3.1 Modo interactivo (Cypress Test Runner, util para depurar):

    npx cypress open
    -> elegir "E2E Testing" -> elegir navegador -> seleccionar el spec

3.5 Ejecucion completa + reporte HTML:

    rmdir /s /q reports cypress\screenshots cypress\videos
    npx cypress run
    npm run report
    start reports\index.html

4. REPORTES
------------------------------------------------------------------------
Cada ejecución genera:
- Reportes JSON individuales en  reports/mochawesome/
- Video de cada spec en        cypress/videos/
- Reporte HTML consolidado en  reports/index.html

Para consolidar manualmente el reporte HTML después de una ejecución:

    npm run report

Abrir el resultado:

    start reports\index.html         (Windows)


5. ESTRUCTURA DEL PROYECTO
------------------------------------------------------------------------
    .
    |- cypress.config.js              Configuracion (baseUrl UI, apiUrl REST, reporter)
    |- package.json                   Dependencias y scripts de ejecucion
    |- readme.txt                     Este archivo (instrucciones)
    |- conclusiones.txt               Hallazgos y conclusiones del ejercicio
    |- cypress/
    |   |- e2e/
    |   |   |- ui/compra-saucedemo.cy.js      Escenarios E2E (3 pruebas)
    |   |   |- api/petstore-mascotas.cy.js    Escenarios REST (5 pruebas)
    |   |- support/
    |   |   |- e2e.js                 Archivo de soporte cargado antes de cada spec
    |   |   |- commands.js            Comando reutilizable cy.login()
    |   |- fixtures/                  (vacio; los datos son explicitos en cada spec)
    |   |- screenshots/               Generado en ejecucion (no versionado)
    |   |- videos/                    Generado en ejecucion (no versionado)
    |- reports/                       Generado en ejecucion
    |- .gitignore

6. ESCENARIOS CUBIERTOS
------------------------------------------------------------------------
E2E - SauceDemo (https://www.saucedemo.com/)
  1. Compra completa con standard_user:
     login -> agregar 2 productos -> validar contador del carrito ->
     visualizar carrito (2 items y nombres) -> completar formulario de
     compra -> validar total calculado -> finalizar -> confirmacion
     "THANK YOU FOR YOUR ORDER".
  2. Usuario bloqueado (locked_out_user): se rechaza el acceso y se
     muestra el mensaje de cuenta bloqueada.
  3. Credenciales invalidas: se muestra el mensaje de error de login.

APIS - PetStore (https://petstore.swagger.io/v2)
  1. POST /pet                      Añadir una mascota a la tienda.
  2. GET  /pet/{id}                 Consultar la mascota ingresada (busqueda por ID).
  3. PUT  /pet                      Actualizar nombre y status a "sold".
  4. GET  /pet/findByStatus?status=sold   Consultar la mascota modificada
                                    por status (busqueda por status).
  5. GET  /pet/{id} inexistente     Caso negativo: 404 "Pet not found".

Nota sobre los casos de API: el identificador de la mascota se genera en el
caso 1 y se reutiliza en los casos 2, 3 y 4, por lo que esas pruebas se
ejecutan encadenadas dentro del mismo spec y en ese orden (Cypress ejecuta
los "it" de un archivo en orden de definicion).

7. CONSIDERACIONES TECNICAS
------------------------------------------------------------------------
- Los sitios son demos publicos: no requieren credenciales propias ni
  levantar infraestructura local.
- SauceDemo: usuario estandar "standard_user" / password "secret_sauce".
  El sitio publica seis usuarios con comportamientos distintos
  (locked_out_user, problem_user, performance_glitch_user, etc.).
- PetStore: la instancia es compartida por todos los usuarios de internet,
  por eso el caso 4 filtra la respuesta por el id generado en lugar de
  asumir que la lista contiene solo el registro propio.
- Se configuro 1 reintento en modo headless (retries.runMode = 1) para
  absorber la latencia variable de los demos publicos; en modo interactivo
  no hay reintentos, de forma que los fallos se vean de inmediato.
- El texto de confirmacion de SauceDemo se muestra en mayusculas por CSS;
  en el DOM real es "Thank you for your order!". La prueba normaliza el
  texto con toUpperCase() antes de comparar contra "THANK YOU FOR YOUR ORDER".

