const { defineConfig } = require('cypress')

module.exports = defineConfig({
  e2e: {
    // Url UI
    baseUrl: 'https://www.saucedemo.com',
    // Url API
    expose: {
      apiUrl: 'https://petstore.swagger.io/v2'
    },
    specPattern: 'cypress/e2e/**/*.cy.js',
    supportFile: 'cypress/support/e2e.js',
    viewportWidth: 1280,
    viewportHeight: 800,
    defaultCommandTimeout: 10000,
    requestTimeout: 20000,
    responseTimeout: 30000,
    video: true,
    screenshotOnRunFailure: true,
    retries: {
      runMode: 1,
      openMode: 0
    },
    reporter: 'mochawesome',
    reporterOptions: {
      reportDir: 'reports/mochawesome',
      overwrite: false,
      html: false,
      json: true,
      timestamp: 'isoDateTime',
      charts: true
    },
    setupNodeEvents (on, config) {
      return config
    }
  }
})
