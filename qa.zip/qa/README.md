# Prueba técnica — Automatización E2E y Pruebas de APIs

Resolución de los dos ejercicios del enunciado con un único framework (**Cypress 16**), un solo repositorio y una sola forma de ejecución.

| Ejercicio | Opción elegida | Sitio |
|---|---|---|
| Automatización E2E | Opción 2 | https://www.saucedemo.com/ |
| APIs (servicios REST) | Opción 2 | https://petstore.swagger.io/v2 |

## Resultado de la última ejecución

```
Suite E2E  : 3 pruebas — 3 exitosas
Suite APIS : 5 pruebas — 5 exitosas
Total      : 8 pruebas — 8 exitosas — 0 fallos
```

Reporte consolidado: [`reports/index.html`](reports/index.html)

## Inicio rápido

```bash
npm install        # instala Cypress y las utilidades de reporte
npm test           # ejecuta las dos suites en modo headless
npm run report     # consolida el reporte HTML en reports/index.html
```

Ejecuciones parciales:

```bash
npm run test:ui    # solo SauceDemo (E2E)
npm run test:api   # solo PetStore (REST)
npx cypress open   # modo interactivo
```

Instrucciones detalladas paso a paso: [`readme.txt`](readme.txt)
Hallazgos y conclusiones: [`conclusiones.txt`](conclusiones.txt)

## Estructura

```
├── cypress.config.js                  # baseUrl UI, expose.apiUrl REST, reporter
├── cypress/
│   ├── e2e/ui/compra-saucedemo.cy.js  # 3 escenarios E2E
│   ├── e2e/api/petstore-mascotas.cy.js# 5 escenarios REST
│   └── support/                       # support file + comando cy.login()
├── reports/                           # reporte HTML y JSON de ejecución
├── readme.txt                         # instrucciones de ejecución
└── conclusiones.txt                   # hallazgos del ejercicio
```

## Escenarios

**E2E — SauceDemo**

1. Compra completa con `standard_user`: login → 2 productos → contador del carrito → carrito → formulario → total → confirmación `THANK YOU FOR YOUR ORDER`.
2. Usuario bloqueado (`locked_out_user`): acceso rechazado.
3. Credenciales inválidas: mensaje de error de login.

**API — PetStore**

1. `POST /pet` — añadir mascota.
2. `GET /pet/{id}` — consultar por ID.
3. `PUT /pet` — actualizar nombre y status a `sold`.
4. `GET /pet/findByStatus?status=sold` — consultar por status.
5. `GET /pet/{id}` inexistente — caso negativo, `404 Pet not found`.

## Notas técnicas

- Un solo framework para UI y REST: `cy.visit`/`cy.get` para el navegador y `cy.request` para los servicios.
- Los casos de API se ejecutan encadenados: el `id` se genera en el caso 1 y se reutiliza en los casos 2–4 (ciclo de vida del recurso).
- PetStore es una instancia pública compartida: el caso 4 filtra la respuesta por `id`, nunca por posición ni por nombre.
- 1 reintento en modo headless para absorber la latencia de los demos públicos; 0 reintentos en modo interactivo.
- Requisitos: Node.js 18+ (probado con 22.22.2) y conexión a internet.

## Requisitos del enunciado cubiertos

- [x] Scripts y archivos de implementación de ambos ejercicios
- [x] Reporte de ejecución
- [x] `readme.txt` con instrucciones paso a paso
- [x] `conclusiones.txt` con hallazgos y conclusiones
- [x] Repositorio público con una sola URL para E2E y APIs
