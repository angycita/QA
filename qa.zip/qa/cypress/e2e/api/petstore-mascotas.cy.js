/**
 * Ejercicio APIS - Opcion 2 (PetStore, recurso pet)
 * Casos: crear -> consultar por ID -> actualizar nombre y status a sold -> consultar por status
 */
describe('API | PetStore - gestion de mascotas', () => {
  // Cypress 16 removed Cypress.env(); Cypress.expose() reads non-sensitive config values
  const api = () => Cypress.expose('apiUrl')

  const petName = 'hermes-qa-pet'
  const updatedName = 'hermes-qa-pet-sold'

  // Populated by the first test and reused by the next ones (same spec process)
  let petId

  it('1. Anade una mascota a la tienda (POST /pet)', () => {
    petId = Date.now()

    cy.request({
      method: 'POST',
      url: `${api()}/pet`,
      body: {
        id: petId,
        category: { id: 1, name: 'dog' },
        name: petName,
        photoUrls: ['https://example.com/pet.png'],
        tags: [{ id: 1, name: 'qa' }],
        status: 'available'
      }
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.id).to.eq(petId)
      expect(response.body.name).to.eq(petName)
      expect(response.body.status).to.eq('available')
    })
  })

  it('2. Consulta la mascota ingresada previamente por ID (GET /pet/{petId})', () => {
    cy.request({
      method: 'GET',
      url: `${api()}/pet/${petId}`
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.id).to.eq(petId)
      expect(response.body.name).to.eq(petName)
      expect(response.body.status).to.eq('available')
    })
  })

  it('3. Actualiza el nombre y el status a sold (PUT /pet)', () => {
    cy.request({
      method: 'PUT',
      url: `${api()}/pet`,
      body: {
        id: petId,
        category: { id: 1, name: 'dog' },
        name: updatedName,
        photoUrls: ['https://example.com/pet.png'],
        tags: [{ id: 1, name: 'qa' }],
        status: 'sold'
      }
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.id).to.eq(petId)
      expect(response.body.name).to.eq(updatedName)
      expect(response.body.status).to.eq('sold')
    })
  })

  it('4. Consulta la mascota modificada por status (GET /pet/findByStatus?status=sold)', () => {
    cy.request({
      method: 'GET',
      url: `${api()}/pet/findByStatus`,
      qs: { status: 'sold' }
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body).to.be.an('array')

      // The public instance is shared, so the list contains many pets: filter by our id
      const found = response.body.find((pet) => pet.id === petId)

      expect(found, `mascota con id ${petId} en la lista de status sold`).to.not.be.undefined
      expect(found.name).to.eq(updatedName)
      expect(found.status).to.eq('sold')
    })
  })

  it('5. Caso negativo: consulta una mascota inexistente (GET /pet/999999999999)', () => {
    cy.request({
      method: 'GET',
      url: `${api()}/pet/999999999999`,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.eq(404)
      expect(response.body.message).to.eq('Pet not found')
    })
  })
})
