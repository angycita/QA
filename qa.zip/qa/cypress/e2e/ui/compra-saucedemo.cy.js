/**
 * Ejercicio E2E - Opcion 2 (SauceDemo)
 * Flujo: login -> 2 productos al carrito -> carrito -> formulario -> confirmacion
 */
describe('E2E | SauceDemo - flujo de compra completo', () => {
  const USER = 'standard_user'
  const PASSWORD = 'secret_sauce'

  beforeEach(() => {
    cy.clearCookies()
    cy.clearLocalStorage()
  })

  it('compra dos productos y llega a la confirmacion THANK YOU FOR YOUR ORDER', () => {
    // 1. Autenticacion con credenciales validas
    cy.login(USER, PASSWORD)
    cy.url().should('include', '/inventory.html')
    cy.get('.inventory_item').should('have.length.greaterThan', 0)

    // 2. Agregar dos productos distintos al carrito
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
    cy.get('[data-test="add-to-cart-sauce-labs-bike-light"]').click()

    // El contador del carrito refleja los dos items agregados
    cy.get('.shopping_cart_badge').should('have.text', '2')

    // 3. Visualizar el carrito y validar su contenido
    cy.get('.shopping_cart_link').click()
    cy.url().should('include', '/cart.html')
    cy.get('.cart_item').should('have.length', 2)
    cy.contains('.cart_item', 'Sauce Labs Backpack').should('be.visible')
    cy.contains('.cart_item', 'Sauce Labs Bike Light').should('be.visible')

    // 4. Completar el formulario de compra (checkout)
    cy.get('[data-test="checkout"]').click()
    cy.url().should('include', '/checkout-step-one.html')
    cy.get('[data-test="firstName"]').type('Angélica')
    cy.get('[data-test="lastName"]').type('Zavala')
    cy.get('[data-test="postalCode"]').type('170150')
    cy.get('[data-test="continue"]').click()

    // Pantalla de resumen: valida que el total se calcule y muestre
    cy.url().should('include', '/checkout-step-two.html')
    cy.get('.cart_item').should('have.length', 2)
    cy.get('.summary_total_label')
      .invoke('text')
      .should('match', /Total:\s*\$\d+\.\d{2}/)

    // 5. Finalizar la compra hasta la confirmacion
    cy.get('[data-test="finish"]').click()
    cy.url().should('include', '/checkout-complete.html')

    // El texto se muestra en mayusculas por CSS y termina en "!"; se normaliza antes de comparar
    cy.get('[data-test="complete-header"]')
      .invoke('text')
      .then((text) => text.trim().toUpperCase())
      .should('include', 'THANK YOU FOR YOUR ORDER')

    cy.get('[data-test="back-to-products"]').should('be.visible')
  })

  it('bloquea el acceso de un usuario bloqueado', () => {
    cy.login('locked_out_user', PASSWORD)

    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain', 'Epic sadface: Sorry, this user has been locked out')
    cy.url().should('not.include', '/inventory.html')
  })

  it('rechaza credenciales invalidas', () => {
    cy.login(USER, 'password_incorrecto')

    cy.get('[data-test="error"]')
      .should('be.visible')
      .and('contain', 'Epic sadface: Username and password do not match')
  })
})
