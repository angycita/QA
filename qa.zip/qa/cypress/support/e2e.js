// Loaded automatically before every spec file
require('./commands')
